const tabs=document.querySelectorAll('.tab');
const panels=document.querySelectorAll('.price-panel');
tabs.forEach(tab=>tab.addEventListener('click',()=>{
  tabs.forEach(t=>t.classList.remove('active'));
  panels.forEach(p=>p.classList.remove('active'));
  tab.classList.add('active');
  document.getElementById(tab.dataset.tab).classList.add('active');
}));

const toast=document.getElementById('toast');
document.querySelectorAll('.order').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const service=btn.dataset.service;
    const price=btn.dataset.price;
    const msg=`السلام عليكم، عايز أطلب خدمة من SMM & Maher%0Aالخدمة: ${encodeURIComponent(service)}%0Aالسعر لكل 1000: ${encodeURIComponent(price)}%0Aالكمية: `;
    toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'),2200);
    window.open(`https://wa.me/201033378085?text=${msg}`,'_blank');
  });
});
